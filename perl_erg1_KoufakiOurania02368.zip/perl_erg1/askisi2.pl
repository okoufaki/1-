print "enter your favourite colour:";

my $colour=<SIDIN>;
chomp ($colour);

print("your favourite colour is $colour.\n");