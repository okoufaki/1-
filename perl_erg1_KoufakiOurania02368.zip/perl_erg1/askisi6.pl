@fruits=("apple", "banana");
push (@fruit, "grape");

print @fruits;