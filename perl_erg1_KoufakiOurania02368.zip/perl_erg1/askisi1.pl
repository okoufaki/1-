#!/usr/bin/perl

use strict;
use warnings;

my $name = "John Doe";
print "Name:$name\n";