$string = "caterpillar";

$x = substr($string, 0, 3);
print $x;